# APDaily
This package allows you to watch AP Classroom Videos automatically.
## Authors
- [@SarangaR](https://www.github.com/SarangaR)
## Installation
Install APDaily-dev with pip
```bash
  pip install apdaily
```
## Requirements
* pynput

