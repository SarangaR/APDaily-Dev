import os
import apdaily_methods.apdaily_m1 as m2
import apdaily_startup.apdaily_startup_main as m1

def run():
    m1.run()
    m2.run()